import { Component } from '@angular/core';

@Component({
  selector: 'app-carte',
  imports: [],
  template: ` <ng-content></ng-content> `,
  styles: `
    :host {
      border: black 1px solid;
      padding: 10px;
    }
  `,
})
export class Carte {}
