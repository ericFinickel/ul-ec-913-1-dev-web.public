import { HttpEvent, HttpHandlerFn, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Authentification } from '../services/authentification';
import { inject } from '@angular/core';

export function authIntercepteur(
  req: HttpRequest<unknown>,
  next: HttpHandlerFn,
): Observable<HttpEvent<unknown>> {
  const authToken = inject(Authentification).auth();
  const newReq = req.clone({ headers: req.headers.append('AUTENTH', authToken) });
  return next(newReq);
}
