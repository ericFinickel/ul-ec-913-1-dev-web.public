import { Injectable, signal } from '@angular/core';
import { Personne } from '../../shared/bean/personne';

@Injectable({
  providedIn: 'root',
})
export class PersonneService {
  public personnes = signal<Personne[]>([
    { nom: 'eric', age: 36 },
    { nom: 'daniel', age: 28 },
    { nom: 'alexandro', age: 39 },
  ]);

  personneSelectionne = signal<Personne | null>(null);

  gommer() {
    this.personneSelectionne.set(null);
    this.personnes.set(this.personnes().filter((p) => p.age < 33));
  }
}
