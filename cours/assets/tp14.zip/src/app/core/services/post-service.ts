import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { forkJoin, Observable, of, switchMap } from 'rxjs';
import { Comment, Post, PostEtComments } from '../bean/post';

@Injectable({
  providedIn: 'root',
})
export class PostService {
  private http = inject(HttpClient);

  public getPost1(): Observable<Post> {
    return this.http.get<Post>('https://jsonplaceholder.typicode.com/posts/1');
  }

  getPost(id: string): Observable<Post> {
    return this.http.get<Post>('https://jsonplaceholder.typicode.com/posts/' + id);
  }

  public getComments1(): Observable<Comment[]> {
    return this.http.get<Comment[]>('https://jsonplaceholder.typicode.com/posts/1/comments');
  }

  public getPost1EtCommentsEnParralle(): Observable<PostEtComments> {
    return forkJoin({
      post: this.getPost1(),
      comments: this.getComments1(),
    });
  }

  public getPost1EtCommentsSequentiel(): Observable<PostEtComments> {
    return this.getPost1().pipe(
      switchMap((post) =>
        forkJoin({
          post: of(post),
          comments: this.getComments1(),
        }),
      ),
    );
  }

  public getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
  }
}
