import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostsAuthentifie } from './posts-authentifie';

describe('PostsAuthentifie', () => {
  let component: PostsAuthentifie;
  let fixture: ComponentFixture<PostsAuthentifie>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PostsAuthentifie]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PostsAuthentifie);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
