import { Component, inject, output, signal } from '@angular/core';
import { Authentification } from '../../core/services/authentification';

@Component({
  selector: 'app-login',
  imports: [],
  template: `
    <p>
      <label for="">email</label>
      <input type="text" (change)="email.set($event.target.value)" />
    </p>
    <p>
      <label for="">mdp</label>
      <input type="password" (change)="mdp.set($event.target.value)" />
    </p>
    <p>
      <button (click)="connecter()">Go</button>
    </p>
    <p>{{ auth() }}</p>
  `,
  styles: ``,
})
export class Login {
  email = signal<string>('');
  mdp = signal<string>('');
  connexion = output();

  private autentification = inject(Authentification);
  auth = this.autentification.auth;

  connecter() {
    this.autentification.connecter(this.email(), this.mdp());
    this.connexion.emit();
  }
}
