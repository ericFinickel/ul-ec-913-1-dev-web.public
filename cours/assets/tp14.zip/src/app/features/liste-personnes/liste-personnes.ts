import { Component, input, output, signal } from '@angular/core';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-liste-personnes',
  imports: [],
  template: ` @for (item of personnes(); track $index) {
    <p>
      {{ item.nom }} - {{ item.age }}
      @if (afficherBoutonVoir()) {
        <button (click)="voir(item)">voir</button>
      }
    </p>
  }`,
  styles: ``,
})
export class ListePersonnes {
  public afficherBoutonVoir = input<boolean>(false);
  personneChange = output<Personne>();

  personnes = signal<Personne[]>([
    { nom: 'eric', age: 18 },
    { nom: 'toto', age: 21 },
    { nom: 'jean', age: 17 },
  ]);

  voir(personne: Personne) {
    this.personneChange.emit(personne);
  }
}
