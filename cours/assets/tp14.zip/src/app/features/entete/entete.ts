import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-entete',
  imports: [RouterLink],
  template: ` <p>Ma super application</p>
    <div style="display: flex; gap: 5px">
      <a routerLink="tp8">tp8</a>
      <a routerLink="tp9">tp9</a>
      <a routerLink="tp10">tp10</a>
      <a routerLink="tp11">tp11</a>
      <a routerLink="tp12">tp12</a>
      <a routerLink="tp13">tp13</a>
      <a routerLink="tp14">tp14</a>
    </div>`,
  styles: `
    :host {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: lightgray;
      padding: 20px;
    }
  `,
})
export class Entete {}
