import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp13 } from './tp13';

describe('Tp13', () => {
  let component: Tp13;
  let fixture: ComponentFixture<Tp13>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp13]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp13);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
