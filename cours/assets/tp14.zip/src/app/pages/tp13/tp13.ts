import { Component } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-tp13',
  imports: [Carte, RouterOutlet],
  template: `
    <p>TP13</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <router-outlet></router-outlet>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp13 {}
