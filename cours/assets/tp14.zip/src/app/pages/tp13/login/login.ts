import { Component, inject } from '@angular/core';
import { Login } from '../../../features/login/login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  imports: [Login],
  template: ` <app-login (connexion)="rediriger()"></app-login> `,
  styles: ``,
})
export class LoginPage {
  router = inject(Router);
  rediriger() {
    this.router.navigateByUrl('/tp13/main');
  }
}
