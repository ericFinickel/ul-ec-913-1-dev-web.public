import { Routes } from '@angular/router';
import { PostsAuthentifiePage } from './posts-authentifie-page/posts-authentifie-page';
import { LoginPage } from './login/login';
import { Tp13 } from './tp13';

export const routes: Routes = [
  {
    path: '',
    component: Tp13,
    children: [
      { path: 'login', component: LoginPage },
      { path: 'main', component: PostsAuthentifiePage },
      { path: '', pathMatch: 'full', redirectTo: 'login' },
    ],
  },
];
