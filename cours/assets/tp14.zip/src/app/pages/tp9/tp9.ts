import { Component } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { ChiffreLePlusGrand } from '../../features/chiffre-le-plus-grand/chiffre-le-plus-grand';

@Component({
  selector: 'app-tp9',
  imports: [Carte, ChiffreLePlusGrand],
  template: `
    <p>TP9</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-chiffre-le-plus-grand></app-chiffre-le-plus-grand>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp9 {}
