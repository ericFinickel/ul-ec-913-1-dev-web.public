import { Component, inject } from '@angular/core';
import { PostService } from '../../../core/services/post-service';
import { toSignal } from '@angular/core/rxjs-interop';
import { Post } from '../../../core/bean/post';
import { Router } from '@angular/router';

@Component({
  selector: 'app-selection-posts-page',
  imports: [],
  template: `
    <ul>
      @for (item of posts(); track $index) {
        <li>{{ item.title }} <button (click)="naviguer(item)">go</button></li>
      }
    </ul>
  `,
  styles: ``,
})
export class SelectionPostsPage {
  postsService = inject(PostService);
  posts = toSignal(this.postsService.getPosts());
  router = inject(Router);

  naviguer(post: Post) {
    this.router.navigate(['tp14/detail/', post.id]);
  }
}
