import { Component, input } from '@angular/core';

@Component({
  selector: 'app-detail-post-page',
  template: `{{ id() }}`,
  styles: ``,
})
export class DetailPostPage {
  id = input<string>();
}
