import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailPostPage } from './detail-post-page';

describe('DetailPostPage', () => {
  let component: DetailPostPage;
  let fixture: ComponentFixture<DetailPostPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailPostPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetailPostPage);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
