import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp14 } from './tp14';

describe('Tp14', () => {
  let component: Tp14;
  let fixture: ComponentFixture<Tp14>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp14]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp14);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
