import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp12 } from './tp12';

describe('Tp12', () => {
  let component: Tp12;
  let fixture: ComponentFixture<Tp12>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp12]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp12);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
