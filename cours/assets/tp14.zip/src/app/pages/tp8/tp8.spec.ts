import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp8 } from './tp8';

describe('Tp8', () => {
  let component: Tp8;
  let fixture: ComponentFixture<Tp8>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp8]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp8);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
