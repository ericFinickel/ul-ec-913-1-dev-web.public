import { Component, signal } from '@angular/core';
import { PropertyEtEventBinding } from '../property-et-event-binding/property-et-event-binding';
import { Carte } from '../../shared/composants/carte/carte';
import { ListePersonnes } from '../liste-personnes/liste-personnes';
import { CouleurCestBeau } from '../couleur-cest-beau/couleur-cest-beau';
import { ChiffreLePlusGrand } from '../chiffre-le-plus-grand/chiffre-le-plus-grand';
import { DetailPersonne } from '../detail-personne/detail-personne';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-contenu',
  imports: [
    PropertyEtEventBinding,
    Carte,
    ListePersonnes,
    CouleurCestBeau,
    ChiffreLePlusGrand,
    DetailPersonne,
  ],
  template: `
    <p>TP8</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-property-et-event-binding></app-property-et-event-binding>
      </app-carte>
      <app-carte>
        <app-liste-personnes></app-liste-personnes>
      </app-carte>
      <app-carte>
        <app-couleur-cest-beau></app-couleur-cest-beau>
      </app-carte>
    </div>
    <p>TP9</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-chiffre-le-plus-grand></app-chiffre-le-plus-grand>
      </app-carte>
    </div>
    <p>TP10</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-liste-personnes
          [afficherBoutonVoir]="true"
          (personneChange)="changerPersonne($event)"
        ></app-liste-personnes>
      </app-carte>
      <app-carte>
        <app-detail-personne [personne]="personne()"></app-detail-personne>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Contenu {
  personne = signal<Personne | undefined>(undefined);

  changerPersonne($event: Personne) {
    this.personne.set($event);
  }

  public titre = signal('Bienvenue');
}
