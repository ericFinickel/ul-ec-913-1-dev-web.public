import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PropertyEtEventBinding } from './property-et-event-binding';

describe('PropertyEtEventBinding', () => {
  let component: PropertyEtEventBinding;
  let fixture: ComponentFixture<PropertyEtEventBinding>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PropertyEtEventBinding]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PropertyEtEventBinding);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
