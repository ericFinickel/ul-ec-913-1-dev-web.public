import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-property-et-event-binding',
  imports: [],
  template: ` <button (click)="toggle()">toggle</button>
    <input [checked]="checked()" type="checkbox" />`,
  styles: ``,
})
export class PropertyEtEventBinding {
  public checked = signal(false);
  toggle() {
    this.checked.set(!this.checked());
  }
}
