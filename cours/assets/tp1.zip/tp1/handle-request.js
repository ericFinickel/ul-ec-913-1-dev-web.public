export const CE_QUE_MON_SERVEUR_FAIT = (req, res) => {
  res.end('Salut les champions !\n');
}