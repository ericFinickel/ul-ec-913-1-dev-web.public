import { createServer } from 'node:http';
import { CE_QUE_MON_SERVEUR_FAIT } from './handle-request.js';

const server = createServer(CE_QUE_MON_SERVEUR_FAIT);

server.listen(3000, () => console.log('Serveur sur http://localhost:3000'));