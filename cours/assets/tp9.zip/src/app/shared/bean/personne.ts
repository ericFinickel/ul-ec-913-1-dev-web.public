export interface Personne {
  nom: string;
  age: number;
}
