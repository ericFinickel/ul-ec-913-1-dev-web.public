import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChiffreLePlusGrand } from './chiffre-le-plus-grand';

describe('ChiffreLePlusGrand', () => {
  let component: ChiffreLePlusGrand;
  let fixture: ComponentFixture<ChiffreLePlusGrand>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChiffreLePlusGrand]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChiffreLePlusGrand);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
