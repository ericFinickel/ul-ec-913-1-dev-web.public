import { Component, input, output, signal } from '@angular/core';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-liste-personnes',
  imports: [],
  template: ` @for (item of personnes(); track $index) {
    <p>{{ item.nom }} - {{ item.age }}</p>
  }`,
  styles: ``,
})
export class ListePersonnes {

  personnes = signal<Personne[]>([
    { nom: 'eric', age: 18 },
    { nom: 'toto', age: 21 },
    { nom: 'jean', age: 17 },
  ]);
}
