import fs from "node:fs/promises";

export type DbObject = { id: number };

export class DbProcess<T extends DbObject> {
  constructor(private path: string) {}

  async nextId(): Promise<number> {
    const elements: T[] = await this.lire();
    const ids: number[] = elements.map((e) => e.id);
    const max = Math.max(...ids);
    return max + 1;
  }

  async lire(): Promise<T[]> {
    const e = await fs.readFile(this.path, { encoding: "utf8" });
    return JSON.parse(e) as T[];
  }

  async ajouter(t: Omit<T, "id">): Promise<T> {
    const elements: T[] = await this.lire();
    const newElement = { ...t, id: await this.nextId() } as T;
    elements.push(newElement);
    await fs.writeFile(this.path, JSON.stringify(elements));
    return newElement;
  }

  public async deleteById(id: number): Promise<T> {
    const elements: T[] = await this.lire();
    const indexElement = elements.findIndex((e) => e.id === id);
    const retour = elements[indexElement];
    elements.splice(indexElement, 1);
    await fs.writeFile(this.path, JSON.stringify(elements));
    return retour;
  }

  async update(id: number, partiel: Partial<Omit<T, "id">>): Promise<T | null> {
    const elements: T[] = await this.lire();
    let retour: T | null = null;
    const newElements = elements.map((e) => {
      if (id === e.id) {
        retour = { ...e, ...partiel };
        return retour;
      }
      return e;
    });
    await fs.writeFile(this.path, JSON.stringify(newElements));
    return retour;
  }
}
