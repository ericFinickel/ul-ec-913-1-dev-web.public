import {
  Joueur,
  JoueurSansId,
  JoueurSansIdPartiel,
  Poste,
} from "../types/joueur";
import { DbProcess } from "./db.process";

export class JoueursProcess {
  private dbProcess = new DbProcess<Joueur>("./joueurs.json");

  public async getJoueurs(): Promise<Joueur[]> {
    return this.dbProcess.lire();
  }

  public async ajouter(joueur: JoueurSansId): Promise<Joueur> {
    return this.dbProcess.ajouter(joueur);
  }

  public async update(
    id: number,
    joueur: JoueurSansIdPartiel
  ): Promise<Joueur | null> {
    return this.dbProcess.update(id, joueur);
  }

  public async supprimer(id: number): Promise<Joueur> {
    return this.dbProcess.deleteById(id);
  }

  public async query(joueurPartiel: Partial<Joueur>): Promise<Joueur[]> {
    const joueurs = await this.getJoueurs();
    return joueurs.filter((j) => this.isPartialEgal(joueurPartiel, j));
  }

  public async getMoyenneBut(poste?: Poste): Promise<number> {
    const joueurPartiel: Partial<Joueur> = {};
    if (poste) {
      joueurPartiel.poste = poste;
    }
    const joueurs = await this.query(joueurPartiel);
    return (
      joueurs.map((j) => j.age).reduce((a, b) => a + b, 0) / joueurs.length
    );
  }

  private isPartialEgal(joueurPartiel: Partial<Joueur>, j: Joueur): boolean {
    return Object.keys(joueurPartiel).every(
      (cle) => joueurPartiel[cle] === j[cle]
    );
  }

  public async getMeilleurButeur(): Promise<Joueur> {
    const e = await this.getJoueurs();
    return e.sort((a, b) => b.nbBut - a.nbBut)[0];
  }
}
