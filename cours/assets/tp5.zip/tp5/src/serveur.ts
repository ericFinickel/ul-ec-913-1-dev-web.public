import express, { Request, Response } from "express";
import { JoueursProcess } from "./process/joueurs-process";
import { Joueur, JoueurSansId, Poste } from "./types/joueur";

const app = express();
const joueursProcess = new JoueursProcess();
app.use(express.json());

app.get("/joueurs", async (req, res) => {
  res.send(await joueursProcess.getJoueurs());
});

app.post("/joueurs/q", async (req, res) => {
  const joueurPartiel: Partial<Joueur> = req.body;
  res.send(await joueursProcess.query(joueurPartiel));
});

app.post("/joueurs", async (req: Request, res: Response) => {
  const joueur: Omit<Joueur, "id"> = req.body;
  await joueursProcess.ajouter(joueur);
  res.status(201).json(joueur);
});

app.patch("/joueurs/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const updates: Partial<JoueurSansId> = req.body;

  const joueurMisAJour = await joueursProcess.update(id, updates);
  res.json(joueurMisAJour);
});

app.delete("/joueurs/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);

  const joueurMisAJour = await joueursProcess.supprimer(id);
  res.json(joueurMisAJour);
});

app.get("/meilleur-buteur", async (req, res) => {
  res.send(await joueursProcess.getMeilleurButeur());
});

app.get("/joueurs/moyenne-but", async (req, res) => {
  const poste = req.query.poste ? (req.query.poste as Poste) : undefined;
  res.send(await joueursProcess.getMoyenneBut(poste));
});

app.listen(3000, () => {
  console.log("Server is running on http://localhost:3000");
});
