import { DbObject } from "../process/db.process";

export type Poste = "Attaquant" | "Milieu" | "Défenseur" | "Gardien";

export interface Joueur extends DbObject {
  nom: string;
  prenom: string;
  age: number;
  poste: Poste;
  nbBut: number;
}

export type JoueurSansId = Omit<Joueur, "id">;

export type JoueurSansIdPartiel = Partial<JoueurSansId>;
