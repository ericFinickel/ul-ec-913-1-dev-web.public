import { Component } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { ListePersonnesAvecService } from '../../features/liste-personnes-avec-service/liste-personnes-avec-service';
import { DetailPersonneAvecService } from '../../features/detail-personne-avec-service/detail-personne-avec-service';

@Component({
  selector: 'app-tp11',
  imports: [Carte, ListePersonnesAvecService, DetailPersonneAvecService],
  template: `
    <p>TP11</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-liste-personnes-avec-service></app-liste-personnes-avec-service>
      </app-carte>
      <app-carte>
        <app-detail-personne-avec-service></app-detail-personne-avec-service>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp11 {}
