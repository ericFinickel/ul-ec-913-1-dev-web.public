import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp11 } from './tp11';

describe('Tp11', () => {
  let component: Tp11;
  let fixture: ComponentFixture<Tp11>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp11]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp11);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
