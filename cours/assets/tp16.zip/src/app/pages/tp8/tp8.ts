import { Component } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { PropertyEtEventBinding } from '../../features/property-et-event-binding/property-et-event-binding';
import { ListePersonnes } from '../../features/liste-personnes/liste-personnes';
import { CouleurCestBeau } from '../../features/couleur-cest-beau/couleur-cest-beau';

@Component({
  selector: 'app-tp8',
  imports: [Carte, PropertyEtEventBinding, ListePersonnes, CouleurCestBeau],
  template: `
    <p>TP8</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-property-et-event-binding></app-property-et-event-binding>
      </app-carte>
      <app-carte>
        <app-liste-personnes></app-liste-personnes>
      </app-carte>
      <app-carte>
        <app-couleur-cest-beau></app-couleur-cest-beau>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp8 {}
