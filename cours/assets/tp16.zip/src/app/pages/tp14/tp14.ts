import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-tp14',
  imports: [RouterOutlet],
  template: ` <router-outlet></router-outlet> `,
  styles: ``,
})
export class Tp14 {}
