import { Routes } from '@angular/router';

import { Tp14 } from './tp14';
import { SelectionPostsPage } from './selection-posts-page/selection-posts-page';
import { DetailPostPage } from './detail-post-page/detail-post-page';

export const routes: Routes = [
  {
    path: '',
    component: Tp14,
    children: [
      { path: 'selection', component: SelectionPostsPage },
      { path: 'detail/:id', component: DetailPostPage },
      { path: '', pathMatch: 'full', redirectTo: 'selection' },
    ],
  },
];
