import { Component, inject, signal } from '@angular/core';
import { PostsAuthentifie } from '../../../features/posts-authentifie/posts-authentifie';
import { Authentification } from '../../../core/services/authentification';

@Component({
  selector: 'app-posts-authentifie-page',
  imports: [PostsAuthentifie],
  template: `
    <p>Salut : {{ user() }}</p>
    <app-posts-authentifie></app-posts-authentifie>
  `,
  styles: ``,
})
export class PostsAuthentifiePage {
  user = signal(atob(inject(Authentification).auth()).replace(':', ' '));
}
