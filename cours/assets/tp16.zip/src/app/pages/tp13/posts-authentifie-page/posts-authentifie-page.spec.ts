import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostsAuthentifiePage } from './posts-authentifie-page';

describe('PostsAuthentifiePage', () => {
  let component: PostsAuthentifiePage;
  let fixture: ComponentFixture<PostsAuthentifiePage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PostsAuthentifiePage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PostsAuthentifiePage);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
