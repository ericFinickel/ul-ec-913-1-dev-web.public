import { Component } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { Posts } from '../../features/posts/posts';

@Component({
  selector: 'app-tp12',
  imports: [Carte, Posts],
  template: `
    <p>TP12</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-posts></app-posts>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp12 {}
