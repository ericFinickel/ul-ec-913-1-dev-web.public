import { Component, signal } from '@angular/core';
import { Carte } from '../../shared/composants/carte/carte';
import { DetailPersonne } from '../../features/detail-personne/detail-personne';
import { ListePersonnes } from '../../features/liste-personnes/liste-personnes';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-tp10',
  imports: [Carte, DetailPersonne, ListePersonnes],
  template: `
    <p>TP10</p>
    <div style="display: flex; gap: 10px">
      <app-carte>
        <app-liste-personnes
          [afficherBoutonVoir]="true"
          (personneChange)="changerPersonne($event)"
        ></app-liste-personnes>
      </app-carte>
      <app-carte>
        <app-detail-personne [personne]="personne()"></app-detail-personne>
      </app-carte>
    </div>
  `,
  styles: ``,
})
export class Tp10 {
  personne = signal<Personne | undefined>(undefined);

  changerPersonne($event: Personne) {
    this.personne.set($event);
  }
}
