import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tp10 } from './tp10';

describe('Tp10', () => {
  let component: Tp10;
  let fixture: ComponentFixture<Tp10>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tp10]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tp10);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
