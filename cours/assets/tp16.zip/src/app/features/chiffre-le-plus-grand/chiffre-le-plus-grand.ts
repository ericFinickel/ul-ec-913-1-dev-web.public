import { Component, computed, Signal, signal, WritableSignal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-chiffre-le-plus-grand',
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form" (ngSubmit)="ajouter()">
      <input type="number" name="chiffre" formControlName="chiffre" />
      <button type="submit">Ajouter</button>
    </form>
    <div style="display: flex; justify-content: space-around">
      <ul>
        @for (item of liste(); track $index) {
          <li>{{ item }}</li>
        }
      </ul>
      <p>{{ plusGrand() }}</p>
    </div>
  `,
  styles: ``,
})
export class ChiffreLePlusGrand {
  liste: WritableSignal<number[]> = signal([]);
  nombre = signal(0);
  plusGrand = computed(() => Math.max(...this.liste()));

  form = new FormGroup({
    chiffre: new FormControl(0),
  });

  setNombre(event: Event) {
    const input = event.target as HTMLInputElement;
    this.nombre.set(Number(input.value));
  }

  ajouter() {
    const v = this.form.controls.chiffre.value;
    if (v) {
      this.liste.update((l) => [...l, v]);
    }
  }
}
