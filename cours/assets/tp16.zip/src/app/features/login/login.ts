import { Component, inject, output, signal } from '@angular/core';
import { Authentification } from '../../core/services/authentification';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form" (ngSubmit)="connecter()">
      <p>
        <label for="">email</label>
        <input type="text" formControlName="email" />
      </p>
      <p>
        <label for="">mdp</label>
        <input type="password" formControlName="mdp" />
      </p>
      <p>
        <button type="submit" (click)="connecter()" [disabled]="!form.valid">Go</button>
      </p>
      <p>{{ auth() }}</p>
    </form>
  `,
  styles: ``,
})
export class Login {
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    mdp: new FormControl('', [Validators.required]),
  });

  connexion = output();
  private autentification = inject(Authentification);
  auth = this.autentification.auth;

  connecter() {
    const email = this.form.controls.email.value!;
    const mdp = this.form.controls.mdp.value!;
    this.autentification.connecter(email, mdp);
    this.connexion.emit();
  }
}
