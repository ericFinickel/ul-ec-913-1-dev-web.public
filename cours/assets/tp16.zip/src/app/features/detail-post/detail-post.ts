import { Component, input } from '@angular/core';
import { Comment, Post } from '../../core/bean/post';

@Component({
  selector: 'app-detail-post',
  imports: [],
  template: `@if (post()) {
      <p>{{ post()!.id }} - {{ post()!.title }}</p>
    }
    <ul>
      @for (item of comments(); track $index) {
        <li>{{ item.name }}</li>
      }
    </ul>`,
  styles: ``,
})
export class DetailPost {
  post = input<Post>();
  comments = input<Comment[]>();
}
