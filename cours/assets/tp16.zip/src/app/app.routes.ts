import { Routes } from '@angular/router';
import { Tp8 } from './pages/tp8/tp8';
import { Tp9 } from './pages/tp9/tp9';
import { Tp10 } from './pages/tp10/tp10';
import { Tp11 } from './pages/tp11/tp11';
import { Tp12 } from './pages/tp12/tp12';
import { Tp13 } from './pages/tp13/tp13';

export const routes: Routes = [
  { path: 'tp8', component: Tp8 },
  { path: 'tp9', component: Tp9 },
  { path: 'tp10', component: Tp10 },
  { path: 'tp11', component: Tp11 },
  { path: 'tp12', component: Tp12 },
  {
    path: 'tp13',
    loadChildren: () => import('./pages/tp13/tp13.routes').then((m) => m.routes),
  },
  {
    path: 'tp14',
    loadChildren: () => import('./pages/tp14/tp14.routes').then((m) => m.routes),
  },
];
