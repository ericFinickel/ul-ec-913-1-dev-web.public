import { Component } from '@angular/core';

@Component({
  selector: 'app-entete',
  imports: [],
  template: ` <p>Ma super application</p> `,
  styles: `
    :host {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: lightgray;
      padding: 20px;
    }
  `,
})
export class Entete {}
