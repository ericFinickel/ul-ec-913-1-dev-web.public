import express from 'express'
import { getJoueurs, getMeilleurButeur } from './joueurs-process.js'

const app = express()

app.get('/joueurs', async (req, res) => {
    res.send(await getJoueurs());
})

app.get('/meilleur-buteur', async (req, res) => {
    res.send(await getMeilleurButeur());
})

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000')
})