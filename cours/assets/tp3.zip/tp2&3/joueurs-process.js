import fs from 'node:fs/promises';

export async function getJoueurs(){
    const e = await fs.readFile('./joueurs.json', { encoding: "utf8" });
    return JSON.parse(e);
}

export async function getMeilleurButeur(){
    const e = await getJoueurs()
    return e.sort((a,b) => b.nbBut - a.nbBut)[0]
}