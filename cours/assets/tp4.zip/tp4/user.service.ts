// userService.js

interface User {
  name: string;
  age: number;
  isAdmin: boolean;
  createdAt: Date;
}

function createUser(name: string, age: number, isAdmin?: boolean): User {
  return {
    name: name,
    age: age,
    isAdmin: isAdmin || false,
    createdAt: new Date(),
  };
}

function getUserLabel(user: User): string {
  return user.name + " (" + user.age + " ans)";
}

function promoteUser(user: User): User {
  if (!user.isAdmin) {
    user.isAdmin = true;
  }
  return user;
}

function averageAge(users: User[]): number | null {
  let total = 0;

  for (let u of users) {
    total += u.age;
  }

  return users.length > 0 ? total / users.length : null;
}

// Exemple d'utilisation
const users: User[] = [
  createUser("Alice", 25),
  createUser("Bob", 30, true),
  createUser("Charlie", 20),
];

console.log("Premier user de la liste : ", getUserLabel(users[0]!));
console.log("Age moyen :", averageAge(users));
