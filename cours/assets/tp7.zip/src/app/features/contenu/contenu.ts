import { Component } from '@angular/core';

@Component({
  selector: 'app-contenu',
  imports: [],
  template: ` <p>mon contenu main</p> `,
  styles: ``,
})
export class Contenu {}
