import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Entete } from './features/entete/entete';
import { Contenu } from './features/contenu/contenu';

@Component({
  selector: 'app-root',
  imports: [Entete, Contenu],
  template: `<app-entete></app-entete>
    <main>
      <app-contenu></app-contenu>
    </main>`,
  styles: `
    main {
      padding: 20px;
    }
  `,
})
export class App {
  protected readonly title = signal('tp6-live');
}
