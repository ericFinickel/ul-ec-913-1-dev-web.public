import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailPersonneAvecService } from './detail-personne-avec-service';

describe('DetailPersonneAvecService', () => {
  let component: DetailPersonneAvecService;
  let fixture: ComponentFixture<DetailPersonneAvecService>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailPersonneAvecService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetailPersonneAvecService);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
