import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CouleurCestBeau } from './couleur-cest-beau';

describe('CouleurCestBeau', () => {
  let component: CouleurCestBeau;
  let fixture: ComponentFixture<CouleurCestBeau>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CouleurCestBeau]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CouleurCestBeau);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
