import { Component, input } from '@angular/core';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-detail-personne',
  imports: [],
  template: ` <p>{{ personne()?.nom }} - {{ personne()?.age }}</p> `,
  styles: ``,
})
export class DetailPersonne {
  personne = input<Personne | null>();
}
