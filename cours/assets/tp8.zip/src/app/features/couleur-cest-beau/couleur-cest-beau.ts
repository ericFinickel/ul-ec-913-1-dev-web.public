import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-couleur-cest-beau',
  imports: [],
  template: `
    <select (change)="checkChange($event)">
      <option value="0">Vide</option>
      <option value="1">Rouge</option>
    </select>
    @if (afficherTexte()) {
      <p style="color: red;">C'est trop beau</p>
    }
  `,
  styles: ``,
})
export class CouleurCestBeau {
  public afficherTexte = signal(false);

  checkChange(event: Event) {
    const select = event.target as HTMLSelectElement;
    const value = select.value;
    this.afficherTexte.set(value === '1');
  }
}
