import { Component, inject, Signal, signal } from '@angular/core';
import { DetailPost } from '../detail-post/detail-post';
import { toSignal } from '@angular/core/rxjs-interop';
import { PostService } from '../../core/services/post-service';
import { Post } from '../../core/bean/post';

@Component({
  selector: 'app-posts-authentifie',
  imports: [DetailPost],
  template: `
    <button (click)="chercherPost1()">go</button>
    @if (post1()) {
      <app-detail-post [post]="post1()!"></app-detail-post>
    }
  `,
  styles: ``,
})
export class PostsAuthentifie {
  public postService = inject(PostService);

  public post1 = signal<Post | null>(null);

  chercherPost1() {
    this.postService.getPost1().subscribe((e) => {
      this.post1.set(e);
    });
  }
}
