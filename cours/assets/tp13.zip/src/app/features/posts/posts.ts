import { Component, inject } from '@angular/core';
import { PostService } from '../../core/services/post-service';
import { toSignal } from '@angular/core/rxjs-interop';
import { DetailPost } from '../detail-post/detail-post';

@Component({
  selector: 'app-posts',
  imports: [DetailPost],
  template: ` <strong>Appel à un post</strong>
    <app-detail-post [post]="post1()"></app-detail-post>
    <strong>Appel // à post et comments</strong>
    <app-detail-post
      [post]="postEtCommentParralle()?.post"
      [comments]="postEtCommentParralle()?.comments"
    ></app-detail-post>
    <strong>Appel sequentiel à post et comments</strong>
    <app-detail-post
      [post]="post1EtCommentsSequentiel()?.post"
      [comments]="post1EtCommentsSequentiel()?.comments"
    ></app-detail-post>`,
  styles: ``,
})
export class Posts {
  private postService = inject(PostService);

  post1 = toSignal(this.postService.getPost1());
  postEtCommentParralle = toSignal(this.postService.getPost1EtCommentsEnParralle());
  post1EtCommentsSequentiel = toSignal(this.postService.getPost1EtCommentsSequentiel());
}
