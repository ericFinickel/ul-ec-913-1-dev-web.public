import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListePersonnesAvecService } from './liste-personnes-avec-service';

describe('ListePersonnesAvecService', () => {
  let component: ListePersonnesAvecService;
  let fixture: ComponentFixture<ListePersonnesAvecService>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListePersonnesAvecService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListePersonnesAvecService);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
