import { Component, inject } from '@angular/core';
import { PersonneService } from '../../core/services/personne-service';
import { Personne } from '../../shared/bean/personne';

@Component({
  selector: 'app-liste-personnes-avec-service',
  imports: [],
  template: `<ul>
      @for (item of personneService.personnes(); track $index) {
        <li>
          {{ item.nom }} - {{ item.age }}
          <button (click)="voir(item)">voir</button>
        </li>
      }
    </ul>
    <button (click)="gommer()">Gommer > 33</button>`,
  styles: ``,
})
export class ListePersonnesAvecService {
  public personneService = inject(PersonneService);

  voir(personne: Personne) {
    this.personneService.personneSelectionne.set(personne);
  }

  gommer() {
    this.personneService.gommer();
  }
}
