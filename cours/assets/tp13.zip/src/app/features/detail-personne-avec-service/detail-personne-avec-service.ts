import { Component, inject } from '@angular/core';
import { PersonneService } from '../../core/services/personne-service';

@Component({
  selector: 'app-detail-personne-avec-service',
  imports: [],
  template: `
    <p>
      {{ personneService.personneSelectionne()?.nom }} -
      {{ personneService.personneSelectionne()?.age }}
    </p>
  `,
  styles: ``,
})
export class DetailPersonneAvecService {
  public personneService = inject(PersonneService);
}
