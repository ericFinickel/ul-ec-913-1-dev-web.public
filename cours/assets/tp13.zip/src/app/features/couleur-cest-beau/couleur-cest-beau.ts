import { Component, Signal, signal } from '@angular/core';

@Component({
  selector: 'app-couleur-cest-beau',
  imports: [],
  template: `<select (change)="onChange($event)">
      <option value="0">Vide</option>
      <option value="1">Rouge</option>
    </select>
    @if (afficherTexte()) {
      <p>Trop beau</p>
    }`,
  styles: ``,
})
export class CouleurCestBeau {
  public afficherTexte = signal(false);

  onChange(event: Event) {
    const select = event.target as HTMLSelectElement;
    this.afficherTexte.set(select.value === '1');
  }
}
