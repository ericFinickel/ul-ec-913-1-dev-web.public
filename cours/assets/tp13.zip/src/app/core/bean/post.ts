export interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

export interface Comment {
  name: string;
}

export interface PostEtComments {
  post: Post;
  comments: Comment[];
}
