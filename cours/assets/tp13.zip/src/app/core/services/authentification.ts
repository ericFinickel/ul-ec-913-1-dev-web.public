import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Authentification {
  public auth = signal<string>('');

  connecter(email: string, mdp: string) {
    this.auth.set(btoa(`${email}:${mdp}`));
  }
}
